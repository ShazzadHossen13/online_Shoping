<?php
$host="localhost";
$usr="root";
$pass="";
$db="shop";
$conn=mysqli_connect($host,$usr,$pass,$db);
?>