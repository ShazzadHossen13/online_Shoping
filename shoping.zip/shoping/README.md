# Online-Shopping-Mini-Project-S5
This is an online shopping project done for my 3rd yr betch mini project.
>**This is implemented using PHP and HTML.**

create a database named **shop** and import the **shop.sql** (in **db** folder) file onto the shop database .

PS: Payment is not implemented
